package jUnitTest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class TestUtilities {
    Manager mangage;
    Boolean emails;
	@Test
	public void happyPath() {
		String email = "bahahaha@yahoo.com";
		emails = Manager.isRealEmail(email);
		assertEquals(emails,true);
	}
	@Test
	public void unhappyPath() {
		String s = "baheeeeee@yahoommmm";
		emails = Manager.isRealEmail(s);
		assertEquals(emails,false);
	}
	@Test
	public void unhappyPath1() {
		String s = "djeiufhre9igju3pwiougj9pwhdgupgh89pgweh";
		emails = Manager.isRealEmail(s);
		assertEquals(emails,false);
	}
	@Test
	public void unhappyPath3() {
		String s = "theNIGEREANPRINCE@@@@@@awesome.com";
		emails = Manager.isRealEmail(s);
		assertEquals(emails,false);
	}
	@Test
	public void unhappyPath4() {
		String s = "ZPRINCE";
		emails = Manager.isRealEmail(s);
		assertEquals(emails,false);
	}
}
