package jUnitTest;

public class Manager {
	String email;
	
	public static boolean isRealEmail(String email) {
		char a;
		int count =0;
		   for(int i =0;i<email.length();i++) {
				a = email.charAt(i);
				if(a =='@') {
					count++;
				}
				if(count>1) {
					return false;
				}
			}
		   if(email.length()<8) { // email has to have a 4 letter ending + @ + shortest @ blank is universities. + has to have a letter at least in front
			   return false;
		   }
            //i was going to attempt to add looking for email provider to make sure it is a real one
		    // with some research i found there are over 5k.
		if(email.contains("@")) {
			if(email.contains(".com") || email.contains(".edu")|| email.contains(".org")|| email.contains(".net")){
				int end = email.length()-4;
				String ending = email.substring(end);
				if(ending.contains(".com")||ending.contains(".edu")||ending.contains(".org")||ending.contains(".net")) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
		return false;
		
	}
	
}

	
